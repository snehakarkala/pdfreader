package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PDFAdapter extends ArrayAdapter<File> {

    Context context;
ViewHolder viewHolder;
ArrayList<File> al_pdf;

    public PDFAdapter(@NonNull Context context,  ArrayList<File> al_pdf) {
        super(context, R.layout.adapter_pdf,al_pdf);
        this.context = context;
        this.al_pdf = al_pdf;
    }

    @Override
    public int getItemViewType(int position)
    {
        return position;

    }


    @Override
    public View getView(final int position,  View convertView,  ViewGroup parent) {

        if(convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.adapter_pdf,parent,false);
            viewHolder= new ViewHolder();
            viewHolder.tv_filename= (TextView)convertView.findViewById(R.id.tv_name);
            convertView.setTag(viewHolder);

        }
          else
        {
            viewHolder=(ViewHolder)convertView.getTag();
        }
          viewHolder.tv_filename.setText(al_pdf.get(position).getName());
          return  convertView;

    }

    @Override
    public int getViewTypeCount() {
        if(al_pdf.size()>0)
        {
            return al_pdf.size();
        }
            else return 1;

        //return super.getViewTypeCount();
    }

    /*
        public PDFAdapter(@NonNull Context context, int resource, int textViewResourceId, Context context1, ViewHolder viewHolder, ArrayList<File> al_pdf) {
            super(context, resource, textViewResourceId);
            this.context = context1;
            this.viewHolder = viewHolder;
            this.al_pdf = al_pdf;
        }
    */


    public class ViewHolder{

        TextView tv_filename;


    }
}


